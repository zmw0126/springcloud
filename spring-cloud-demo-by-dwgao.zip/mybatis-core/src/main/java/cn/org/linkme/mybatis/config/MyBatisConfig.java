package cn.org.linkme.mybatis.config;

import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import tk.mybatis.mapper.autoconfigure.MybatisProperties;

import javax.sql.DataSource;

@Configuration
@tk.mybatis.spring.annotation.MapperScan(basePackages = {"cn.org.linkme.**.dao","cn.org.linkme.**.mapper"})
@ConditionalOnBean({DataSource.class})
@EnableConfigurationProperties({MybatisProperties.class})
@AutoConfigureAfter({DataSourceAutoConfiguration.class})
@AutoConfigureBefore(
        name = {"tk.mybatis.mapper.autoconfigure.MapperAutoConfiguration"}
)
public class MyBatisConfig {

    public MyBatisConfig(MybatisProperties properties){
        if(!StringUtils.hasLength(properties.getTypeAliasesPackage())){
            properties.setTypeAliasesPackage("poker.**.dto");
        }

        if (ObjectUtils.isEmpty(properties.resolveMapperLocations())) {
            properties.setMapperLocations(
                    new String[]{
                            "classpath*:cn/org/linkme/**/mapper/*.xml",
                            "classpath*:cn/org/linkme/**/dao/*.xml"});
        }
    }
}
