package cn.org.linkme.cloud.microservice.config;

import feign.Client;
import feign.Request;
import feign.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.netflix.feign.ribbon.CachingSpringLoadBalancerFactory;
import org.springframework.cloud.netflix.feign.ribbon.LoadBalancerFeignClient;
import org.springframework.cloud.netflix.ribbon.SpringClientFactory;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

@Slf4j
public class MockLoadBalancerFeignClient extends LoadBalancerFeignClient {

    private String baseUrl;

    public MockLoadBalancerFeignClient(String baseUrl, Client delegate, CachingSpringLoadBalancerFactory lbClientFactory, SpringClientFactory clientFactory) {
        super(delegate, lbClientFactory, clientFactory);
        this.baseUrl = baseUrl;
    }

    @Override
    public Response execute(Request request, Request.Options options) throws IOException {

        try {
            URI uri = new URI(request.url());
            uri.getHost();
            String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
                    .path(uri.getHost().toUpperCase())
                    .path(uri.getPath())
                    .query(uri.getQuery())
                    .build().toUriString();
            return this.getDelegate().execute(
                    Request.create(
                            request.method(),
                            url,
                            request.headers(),
                            request.body(),
                            request.charset()
                    ),options);

        } catch (URISyntaxException e) {
            log.error("URL解析错误",e);
        }

        return super.execute(request,options);
    }
}
