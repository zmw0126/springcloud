package cn.org.linkme.cloud.microservice.config;

import feign.Client;
import feign.Feign;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import okhttp3.logging.HttpLoggingInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.feign.FeignAutoConfiguration;
import org.springframework.cloud.netflix.feign.ribbon.CachingSpringLoadBalancerFactory;
import org.springframework.cloud.netflix.feign.ribbon.LoadBalancerFeignClient;
import org.springframework.cloud.netflix.ribbon.SpringClientFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@ConditionalOnClass(Feign.class)
@EnableCircuitBreaker
@EnableFeignClients(basePackages = "cn.org.linkme.**.*")
@Configuration
@AutoConfigureBefore(FeignAutoConfiguration.class)
public class FeignClientConfig {

    @Value("${gateway.baseUrl:https://api.linkme.org.cn/}")
    private String baseUrl;

    @RefreshScope
    @Profile("default")
    @Bean
    public Client feignClient( @Autowired(required = false) CachingSpringLoadBalancerFactory cachingFactory,@Autowired(required = false) SpringClientFactory clientFactory){

        return new MockLoadBalancerFeignClient(
                baseUrl,delegate(),
                cachingFactory, clientFactory);
    }

    public Client delegate(){
        return (request, options) ->{
            OkHttpClient okHttpClient = commonBuilder()
                    .connectTimeout(options.connectTimeoutMillis(),TimeUnit.MILLISECONDS)
                    .readTimeout(options.readTimeoutMillis(),TimeUnit.MILLISECONDS).build();

            Response response = okHttpClient.newCall(
                    new Request.Builder()
                            .url(request.url())
                            .method(request.method(),request.body()==null?null:RequestBody.create(MediaType.parse("application/json"),request.body()))
                            .build()).execute();

            Map<String, Collection<String>> headers = new HashMap<>();

            response.headers().toMultimap().entrySet().stream().forEach(entry->headers.put(entry.getKey(),entry.getValue()));

            return feign.Response.builder()
                    .body(response.body().bytes())
                    .headers(headers)
                    .status(response.code())
                    .reason(response.message()).build();
        };
    }

    @RefreshScope
    @Profile("!default")
    @Bean
    public Client loadBalanceFeignClient( @Autowired(required = false) CachingSpringLoadBalancerFactory cachingFactory,@Autowired(required = false) SpringClientFactory clientFactory){

        return new LoadBalancerFeignClient(delegate(),
                cachingFactory, clientFactory);
    }

    @RefreshScope
    @Bean
    public OkHttpClient okHttpClient(){
        return commonBuilder().build();
    }

    public OkHttpClient.Builder commonBuilder(){

        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.HEADERS);

        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .connectionPool(new ConnectionPool());

        return builder.addNetworkInterceptor(chain ->
        {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            if(authentication==null){
                return chain.proceed(chain.request());
            }

            OAuth2AuthenticationDetails details = (OAuth2AuthenticationDetails) authentication.getDetails();
            String token = details.getTokenValue();

            if(StringUtils.isEmpty(token)){
                return chain.proceed(chain.request());
            }

            return chain.proceed(
                    chain.request().newBuilder()
                            .header("Authorization","Bearer " + token)
                            .build()
            );
        }).addNetworkInterceptor(httpLoggingInterceptor);
    }
}
