package cn.org.linkme.cloud.microservice.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Configuration;

@ConditionalOnMissingBean(JwtFilterConfig.class)
@ServletComponentScan("cn.org.linkme.cloud.microservice.filter")
@Configuration
public class JwtFilterConfig {
}
