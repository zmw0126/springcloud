import styled from "styled-components";
import { Row,Form } from "antd";
import Content from "../../components/Content";

export const ManagementWrapper = styled(Content)`
	
`;