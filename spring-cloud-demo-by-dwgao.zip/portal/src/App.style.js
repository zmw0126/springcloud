import styled,{injectGlobal} from "styled-components";

injectGlobal`
	body{
		
	}
`;

export const FooterWrapper = styled.div`
	width:100%;
	height:64px;
	text-align:center;
	.ant-divider-horizontal{
		margin:0px 0px 20px 10px;
	}
`;