export default {
  apiUrl: 'http://api.demo.io',
  tokenUrl: 'http://demo_client:demo_secret@account.demo.io/oauth/token',
  client_id: 'demo_client',
  client_secret: 'demo_secret'
};