import { createActions } from "redux-actions";

const actions = createActions({
	CONNECT:undefined,
	DISCONNECT:undefined
});

export default actions;