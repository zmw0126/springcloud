package demo.ms.user.repository;

import demo.ms.common.entity.UserProjectRef;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserProjectRefRepository extends JpaRepository<UserProjectRef,Long> {
}
